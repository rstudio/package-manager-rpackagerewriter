library(testthat)
library(SecondMD5)

test_check("SecondMD5")
