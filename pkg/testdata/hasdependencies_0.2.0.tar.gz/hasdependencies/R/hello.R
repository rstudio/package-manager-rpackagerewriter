square <- function(x) {
  x^2
}
